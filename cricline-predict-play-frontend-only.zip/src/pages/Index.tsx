
import { useEffect, useState } from "react";
import { MainLayout } from "@/components/layout/main-layout";
import { MatchCard } from "@/components/cricket/match-card";
import { Skeleton } from "@/components/ui/skeleton";
import { supabase } from "@/lib/supabase";

export default function Index() {
  const [matches, setMatches] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchMatches = async () => {
      setIsLoading(true);
      const { data, error } = await supabase
        .from("matches")
        .select("*")
        .order("date", { ascending: true });

      if (error) {
        console.error("Error fetching matches:", error);
      } else {
        setMatches(data || []);
      }

      setIsLoading(false);
    };

    fetchMatches();
  }, []);

  const now = new Date().toISOString();
  const upcomingMatches = matches.filter(m => m.date > now);
  const liveMatches = matches.filter(m => m.status?.toLowerCase().includes("live"));

  return (
    <MainLayout>
      <div className="p-4">
        <h2 className="text-xl font-bold mb-2">Live Matches</h2>
        {isLoading
          ? <Skeleton className="h-24 w-full" />
          : liveMatches.map(match => <MatchCard key={match.id} match={match} />)}

        <h2 className="text-xl font-bold mt-6 mb-2">Upcoming Matches</h2>
        {isLoading
          ? <Skeleton className="h-24 w-full" />
          : upcomingMatches.map(match => <MatchCard key={match.id} match={match} />)}
      </div>
    </MainLayout>
  );
}
